Centro Universitario Senac Santo Amaro
Engenharia da Computacao
Algoritmos e Progrmacao I - Prof� Fabio Lubacheski

Trabalho 02: kNN pontos mais proximos

Rafael Fortunatti Simoes
Jonathan F. Ram�rez S.


Professor Fabio, este � o arquivo de instru��es para o trabalho 02 do curso, que s�o as seguintes:
-O arquivo de pontos � o "coordenadas.txt" por padr�o, que dever� estar na mesma pasta que o bin�rio de execu��o.
-A estrutura de pontos aceita at� 1000 pontos, por�m pode ser edit�vel pelo macro MAX_PONTOS_VETOR no topo do main.c.
-Constru�mos as fun��es de manipula��o da estrutura inspirado em OOP, com m�todos e inicializa��es. N�o � perfeito pela falta da
	capacidade da linguagem C em definir estruturas de classe e heran�a, por exemplo.
-O arquivo coordenadas.txt tem a seguinte estrutura:
[N PONTOS]
[PONTO 1]
[PONTO 2]
[PONTO N]

